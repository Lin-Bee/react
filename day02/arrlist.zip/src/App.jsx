import React from 'react';
import UserList from './component/UserList';

function App(){
    return(
        <>
        <UserList />
        </>
    );
}

export default App; 